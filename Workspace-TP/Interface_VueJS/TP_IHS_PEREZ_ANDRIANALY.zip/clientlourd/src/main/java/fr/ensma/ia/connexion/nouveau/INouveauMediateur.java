package fr.ensma.ia.connexion.nouveau;

public interface INouveauMediateur {
	
	public boolean estvide() ;

}
