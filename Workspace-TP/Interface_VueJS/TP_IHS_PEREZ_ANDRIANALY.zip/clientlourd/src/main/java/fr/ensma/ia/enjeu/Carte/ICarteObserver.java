package fr.ensma.ia.enjeu.Carte;

public interface ICarteObserver {

}
