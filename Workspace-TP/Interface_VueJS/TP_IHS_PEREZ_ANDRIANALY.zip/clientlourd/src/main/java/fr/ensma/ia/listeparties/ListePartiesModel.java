package fr.ensma.ia.listeparties;

import java.util.ArrayList;
import java.util.List;

public class ListePartiesModel {
	
	public ListePartiesModel() {
		
	}
	
	


	public List<String> getListeParties() {
		// TODO return Liste des parties dispos (PB synchro) 
		return new ArrayList<String>();
	}

}
