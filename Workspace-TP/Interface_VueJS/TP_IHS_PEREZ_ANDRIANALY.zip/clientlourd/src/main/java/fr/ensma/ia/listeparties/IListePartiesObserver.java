package fr.ensma.ia.listeparties;

public interface IListePartiesObserver {
	
	public void connexionfired() ;

	public void HallofFamefired();

}
