package fr.ensma.ia.connexion.nouveau;

public interface INouveauObserver {
	
	public void validationfired() ;

}
