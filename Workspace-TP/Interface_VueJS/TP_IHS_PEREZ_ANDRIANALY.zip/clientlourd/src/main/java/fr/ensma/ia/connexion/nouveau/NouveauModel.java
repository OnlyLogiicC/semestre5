package fr.ensma.ia.connexion.nouveau;

public class NouveauModel {
	
	public NouveauModel() {
		
	}
		
	public void validation() {
		//Interaction avec base de données
	}

	


}
