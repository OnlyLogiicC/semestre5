package fr.ensma.ia.connexion.existant;

public interface IExistantMediateur {
	
	public boolean estvide() ;

}
