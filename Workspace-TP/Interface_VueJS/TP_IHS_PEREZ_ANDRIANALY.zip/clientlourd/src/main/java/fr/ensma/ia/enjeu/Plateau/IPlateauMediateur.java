package fr.ensma.ia.enjeu.Plateau;

public interface IPlateauMediateur {

}
