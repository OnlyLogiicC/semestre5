package fr.ensma.ia.enjeu.Plateau;

public class PlateauModel {
	
	private Integer nbre_cartes ;
	
	public PlateauModel(Integer n) {
		this.nbre_cartes = n ;
	}

	public Integer getNbre_cartes() {
		return nbre_cartes;
	}

	public void setNbre_cartes(Integer nbre_cartes) {
		this.nbre_cartes = nbre_cartes;
	}

}
