package fr.ensma.ia.connexion.existant;

public interface IExistantObserver {
	
	public void validationfired() ;

	public void nouveauUtilisateurfired();

}
