package fr.ensma.ia.enjeu.Carte;

public interface ICarteMediateur {
	
	public void setImage(String label) ;

}
