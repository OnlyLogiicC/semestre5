package fr.ensma.ia.listeparties;

public interface IListePartiesMediateur {
	


}
