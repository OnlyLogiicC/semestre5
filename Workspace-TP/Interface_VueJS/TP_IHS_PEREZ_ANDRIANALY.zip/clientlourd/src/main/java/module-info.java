module fr.ensma.ia {
    requires javafx.controls;
	requires javafx.graphics;
	requires javafx.base;
    exports fr.ensma.ia;
}
