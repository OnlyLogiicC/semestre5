package fr.ensma.ia.Case;

import javafx.scene.image.ImageView;

public interface ICaseMediateur {
	
	public void setImage(ImageView img) ;

}
