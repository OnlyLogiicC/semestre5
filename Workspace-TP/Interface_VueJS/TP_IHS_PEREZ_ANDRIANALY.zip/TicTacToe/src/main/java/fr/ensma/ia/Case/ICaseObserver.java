package fr.ensma.ia.Case;

public interface ICaseObserver {

}
