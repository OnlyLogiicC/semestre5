package fr.ensma.ia.Plateau;

public class PlateauModel {

}
