package fr.ensma.ia.Plateau;

public interface IPlateauMediateur {

}
