module fr.ensma.ia {
    requires javafx.controls;
	requires javafx.base;
	requires javafx.graphics;
    exports fr.ensma.ia;
}
