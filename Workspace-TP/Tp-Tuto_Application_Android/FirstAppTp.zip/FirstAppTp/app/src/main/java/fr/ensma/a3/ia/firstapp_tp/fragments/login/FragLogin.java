package fr.ensma.a3.ia.firstapp_tp.fragments.login;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import fr.ensma.a3.ia.firstapp_tp.R;
import fr.ensma.a3.ia.firstapp_tp.composants.login.ILoginObserver;
import fr.ensma.a3.ia.firstapp_tp.composants.login.Login;

public class FragLogin extends Fragment implements ILoginObserver{

    private Login compoLogin;
    private List<ILoginObserver> mesObs = new ArrayList<ILoginObserver>();;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        compoLogin = (Login)getActivity().findViewById(R.id.compLogin);
        compoLogin.addObserver(this);
    }

    @Override
    public void loginOk(String user) {
        for (ILoginObserver ob : mesObs) {
            ob.loginOk(user);
        }
    }

    public void addObserver(final ILoginObserver ob){
        mesObs.add(ob);
    }
    public void removeObserver(final ILoginObserver ob){
        mesObs.remove(ob);
    }


}
