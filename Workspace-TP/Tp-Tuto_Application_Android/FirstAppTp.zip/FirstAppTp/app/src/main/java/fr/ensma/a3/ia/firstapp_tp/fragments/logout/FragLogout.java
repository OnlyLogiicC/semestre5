package fr.ensma.a3.ia.firstapp_tp.fragments.logout;

import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.DrawableRes;
import androidx.core.view.GestureDetectorCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import fr.ensma.a3.ia.firstapp_tp.R;

public class FragLogout extends Fragment implements
        GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    private List<IFragLogoutObserver> mesObs;

    private GestureDetectorCompat mDetector;
    private ImageView imageBye;
    private int nbDblTap = 0;

    public FragLogout(){
        mesObs = new ArrayList<IFragLogoutObserver>();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_logout, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        imageBye = (ImageView)getActivity().findViewById(R.id.imageLog);
        mDetector = new GestureDetectorCompat(getActivity(),this);
        mDetector.setOnDoubleTapListener(this);
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                mDetector.onTouchEvent(event);
                return true;
            }
        });
    }

    public void addObserver(IFragLogoutObserver ob) {
        mesObs.add(ob);
    }
    public void removeNavigationObserver(IFragLogoutObserver ob){
        mesObs.remove(ob);
    }
    public void setImage(@DrawableRes int resId){
        imageBye.setImageResource(resId);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onDoubleTap(MotionEvent e) {
        Log.i("FirstApp", "onDoubleTapEvent: " + ++nbDblTap + " -> Changement Image");
        for (IFragLogoutObserver ob : mesObs){
            ob.doubleTap();
        }
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent e) {

        return false;
    }

    @Override
    public boolean onDown(MotionEvent e) {
        //toujours car sinon pas d'evenement !!!
        return true;
    }

    @Override
    public void onLongPress(MotionEvent e) {
        Log.i("FirstApp", "onLongPress: C'est long ....");
        for (IFragLogoutObserver ob : mesObs){
            ob.resetApp();
        }
    }

    @Override
    public void onShowPress(MotionEvent e) {
    }

    @Override
    public boolean onSingleTapUp(MotionEvent e) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return false;
    }

    @Override
    public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
        return false;
    }
}
