package fr.ensma.a3.ia.firstapp_tp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import fr.ensma.a3.ia.firstapp_tp.composants.login.ILoginObserver;
import fr.ensma.a3.ia.firstapp_tp.composants.navigation.INavigationObserver;
import fr.ensma.a3.ia.firstapp_tp.composants.navigation.Navigation;
import fr.ensma.a3.ia.firstapp_tp.fragments.login.FragLogin;
import fr.ensma.a3.ia.firstapp_tp.fragments.logout.FragLogout;
import fr.ensma.a3.ia.firstapp_tp.fragments.logout.IFragLogoutObserver;
import fr.ensma.a3.ia.firstapp_tp.fragments.welcome.FragWelcome;

public class MainActivity extends AppCompatActivity implements ILoginObserver, INavigationObserver, IFragLogoutObserver {

    // Composants
    private Navigation navHome, navLogout, navChat, navCapt;
    // Fragments
    private FragLogin frLogin;
    private FragWelcome frWelcome;
    private FragLogout frLogout;

    private int stateImageLog = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // instance composants
        navHome = (Navigation)findViewById(R.id.navHome);
        navLogout = (Navigation)findViewById(R.id.navLogout);
        navChat = (Navigation) findViewById(R.id.navChat);
        navCapt = (Navigation) findViewById(R.id.navCapt);
        // Abonnement Navigation
        navLogout.addNavigationObserver(this);
        // Chargement Fragment Login
        getSupportFragmentManager().beginTransaction().
                replace(R.id.fragmentlayout, new FragLogin(), "FragLogin_Tag")
                .addToBackStack(null)
                .commit();
        getSupportFragmentManager().executePendingTransactions();
        frLogin = (FragLogin)getSupportFragmentManager().findFragmentByTag("FragLogin_Tag");
        frLogin.addObserver(this);
    }

    @Override
    public void loginOk(String user) {
        Log.i("FirstApp", "loginOk: " + user);
        // MaJ Menu Navigation
        navHome.setMenuTextView(user + " Home");
        navHome.setEnable(false);
        navHome.setChecked(true);
        navLogout.setMenuTextView("Bye " + user);
        navLogout.setEnable(true);
        navChat.setEnable(true);
        navCapt.setEnable(true);
        // Chargement Fragment Welcome
        frWelcome = new FragWelcome();
        getSupportFragmentManager().beginTransaction().
                replace(R.id.fragmentlayout, frWelcome, "FragWelc_Tag")
                .addToBackStack(null)
                .commit();
        getSupportFragmentManager().executePendingTransactions();
        frWelcome.setMesWelcome(user);
    }

    @Override
    public void stateChanged(Boolean state, int idcomp) {
        // si Navigation Logout
        if (idcomp == R.id.navLogout) {
            frLogout = new FragLogout();
            frLogout.addObserver(this);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragmentlayout, frLogout, "FragLogout_Tag")
                    .addToBackStack(null)
                    .commit();
            navHome.setMenuTextView("Home ...");
            navHome.setChecked(false);
            navHome.setEnable(false);
            navLogout.setMenuTextView("Bye ...");
            navLogout.setEnable(false);
            navLogout.setChecked(true);
            navChat.setEnable(false);
            navCapt.setEnable(false);
        }
    }

    @Override
    public void resetApp() {
        Log.i("FirstApp", "resetApp: " + "Reset de l'App");
        navLogout.setEnable(false);
        navLogout.setChecked(false);
        frLogin = (FragLogin)getSupportFragmentManager().findFragmentByTag("FragLogin_Tag");
        getSupportFragmentManager().beginTransaction()
                .remove(frLogin);
        frLogin = new FragLogin();
        frLogin.addObserver(this);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentlayout,frLogin)
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void doubleTap() {
        switch (stateImageLog){
            case 0 : frLogout.setImage(R.drawable.lh_logo);
                stateImageLog = 1;
                break;
            case 1 : frLogout.setImage(R.drawable.giphy);
                stateImageLog = 0;
                break;
        }
    }

}