package fr.ensma.a3.ia.firstapp_tp.composants.navigation;

public interface INavigationObserver {

    void stateChanged(final Boolean state, final int idcomp);

}
