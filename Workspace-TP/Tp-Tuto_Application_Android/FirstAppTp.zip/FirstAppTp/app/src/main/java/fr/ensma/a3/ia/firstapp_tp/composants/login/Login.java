package fr.ensma.a3.ia.firstapp_tp.composants.login;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import fr.ensma.a3.ia.firstapp_tp.R;

public class Login extends LinearLayout implements View.OnClickListener {

    private EditText monChpTexte;
    private Button monBouton;
    private TextView monLabel;
    private List<ILoginObserver> mesObs;
    TypedArray att;

    public Login(@NonNull Context context) {
        super(context);
        LayoutInflater.from(context).inflate(R.layout.compo_login, this);
        mesObs = new ArrayList<ILoginObserver>();
    }

    public Login(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater.from(context).inflate(R.layout.compo_login, this);
        setAttr(context,attrs);
    }

    public Login(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater.from(context).inflate(R.layout.compo_login, this);
        setAttr(context,attrs);
    }

    private void setAttr(Context ctx, AttributeSet attrs) {
        mesObs = new ArrayList<ILoginObserver>();
        monChpTexte = (EditText) findViewById(R.id.leChampTexte);
        monBouton = (Button)findViewById(R.id.leBouton);
        monLabel = (TextView)findViewById(R.id.leLabel);
        monBouton.setOnClickListener(this);
        att = ctx.obtainStyledAttributes(attrs,
                R.styleable.Login);
        monChpTexte.setText(att.getString(R.styleable.Login_labChptxt));
        monLabel.setText("Donne ton nom ...");
        monBouton.setText(att.getString(R.styleable.Login_labBouton));
        monBouton.setEnabled(att.getBoolean(R.styleable.Login_activLogin,true));
        monChpTexte.setEnabled(att.getBoolean(R.styleable.Login_activLogin,true));
    }

    @Override
    public void onClick(View v) {
        if(!(monChpTexte.getText().toString().compareTo("")==0)) {
            monLabel.setText(monChpTexte.getText());
            for (ILoginObserver ob : mesObs) {
                ob.loginOk(monChpTexte.getText().toString());
            }
            monChpTexte.setEnabled(false);
            monBouton.setEnabled(false);
        }
    }

    public void addObserver(final ILoginObserver ob){
        mesObs.add(ob);
    }
    public void removeObserver(final ILoginObserver ob){
        mesObs.remove(ob);
    }
}
