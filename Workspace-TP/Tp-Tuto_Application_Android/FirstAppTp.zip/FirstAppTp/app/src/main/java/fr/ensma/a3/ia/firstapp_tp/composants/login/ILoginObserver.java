package fr.ensma.a3.ia.firstapp_tp.composants.login;

public interface ILoginObserver {

    void loginOk(final String user);
}
