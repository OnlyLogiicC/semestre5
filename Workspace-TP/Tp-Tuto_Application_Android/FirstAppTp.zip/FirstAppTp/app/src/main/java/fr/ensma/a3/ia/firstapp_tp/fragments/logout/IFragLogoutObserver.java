package fr.ensma.a3.ia.firstapp_tp.fragments.logout;

public interface IFragLogoutObserver {
    void resetApp();
    void doubleTap();
}
