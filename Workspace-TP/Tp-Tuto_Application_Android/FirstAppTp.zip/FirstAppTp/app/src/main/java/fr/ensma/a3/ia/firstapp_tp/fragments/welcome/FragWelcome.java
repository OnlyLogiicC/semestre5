package fr.ensma.a3.ia.firstapp_tp.fragments.welcome;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import fr.ensma.a3.ia.firstapp_tp.R;

public class FragWelcome extends Fragment {

    private TextView mesWelcome;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_welcome, parent, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mesWelcome = (TextView)getActivity().findViewById(R.id.welcText);
    }

    public void setMesWelcome(final String mes) {
        mesWelcome.setText("Bienvenue Mr. " + mes + " !!!");
    }

}
