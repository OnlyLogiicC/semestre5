package fr.ensma.a3.ia.carnetadressesdao.dao.entity;
/**
Package des Entities de la couche DLA.
*/