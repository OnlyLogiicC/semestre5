package fr.ensma.a3.ia.carnetadressesdao.dao;
/**
Package regoupant la couche DLA de l'application carnet Adresses
*/