package fr.ensma.ia.elementsjeu.bonus;

import fr.ensma.ia.elementsjeu.cartes.ICarte;

public class Amulette extends AbstractBonus {

	public Amulette(ICarte carte) {
		super(carte);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tournerCarte() {
		// action classique + action amulette
		
	}
	
	
	

}
