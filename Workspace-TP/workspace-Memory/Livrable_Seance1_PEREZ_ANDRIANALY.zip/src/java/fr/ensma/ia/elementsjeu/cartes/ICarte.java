package fr.ensma.ia.elementsjeu.cartes;

public interface ICarte {
	
	public void tournerCarte() ;

}
