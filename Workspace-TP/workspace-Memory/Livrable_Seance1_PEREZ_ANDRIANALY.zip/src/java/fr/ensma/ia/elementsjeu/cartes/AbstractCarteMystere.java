package fr.ensma.ia.elementsjeu.cartes;

public abstract class AbstractCarteMystere extends AbstractCarte {
	
	public AbstractCarteMystere(String id, Integer pos) {
		super(id, pos);
		// TODO Auto-generated constructor stub
	}
	

	public void effetMystere() {
		
	}

}
