package fr.ensma.ia.elementsjeu.cartes.automateCarte;

public interface IEtatCarte {
	
	public void Retourner() ;
	public void Retirer() ;
	public void Replacer() ;

}
