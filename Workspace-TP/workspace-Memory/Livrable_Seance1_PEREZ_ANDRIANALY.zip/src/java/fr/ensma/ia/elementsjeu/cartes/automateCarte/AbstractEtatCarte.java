package fr.ensma.ia.elementsjeu.cartes.automateCarte;

public abstract class AbstractEtatCarte implements IEtatCarte {
	
	public void Retourner() {
		
	}
	
	public void Retirer() {
		
	}
	
	public void Replacer() {
		
	}

}
