package fr.ensma.ia.joueurs;

public class JoueurIA extends AbstractJoueur {
	
	
	public JoueurIA(String pseudo) {
		super(pseudo);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void Jouer() {
		
	}

}
