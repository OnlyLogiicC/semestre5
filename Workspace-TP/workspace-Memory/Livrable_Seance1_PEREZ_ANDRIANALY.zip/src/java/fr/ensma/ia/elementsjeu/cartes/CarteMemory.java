package fr.ensma.ia.elementsjeu.cartes;

public class CarteMemory extends AbstractCarte{

	public CarteMemory(String id, Integer pos) {
		super(id, pos);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tournerCarte() {

		//TODO : action classique de retourner la carte
		
	}
}
