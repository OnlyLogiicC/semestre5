package fr.ensma.ia.elementsjeu.cartes;

public class DansTaFace extends AbstractCarteMystere {

	public DansTaFace(String id, Integer pos) {
		super(id, pos);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tournerCarte() {
		// TODO effet classique + appel de effetMystere()
		
	}
	
	@Override
	public void effetMystere() {
		
	}

}
