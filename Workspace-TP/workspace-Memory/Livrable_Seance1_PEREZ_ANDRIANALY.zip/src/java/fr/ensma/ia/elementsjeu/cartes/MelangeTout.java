package fr.ensma.ia.elementsjeu.cartes;

public class MelangeTout extends AbstractCarteMystere {

	public MelangeTout(String id, Integer pos) {
		super(id, pos);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tournerCarte() {
		// TODO effet classique + appel de effetMystere()
		
	}
	
	@Override
	public void effetMystere() {
		
	}

}
