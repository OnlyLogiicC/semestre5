public class TransitionImpossibleException extends Exception {
    //TODO : gérer l'exception du Pattern State
}