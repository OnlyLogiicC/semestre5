package fr.ensma.ia.elementsjeu.cartes;

public class ReveleTout extends AbstractCarteMystere {

	public ReveleTout(String id, Integer pos) {
		super(id, pos);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void tournerCarte() {
		// TODO effet classique + appel de effetMystere()
		
	}
	
	@Override
	public void effetMystere() {
		
	}

}
